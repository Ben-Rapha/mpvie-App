package com.example.android.movieapp;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;


import com.squareup.picasso.Picasso;

public class DetailActivity extends AppCompatActivity{
    ImageView imageView;
    TextView movieTitle;
    TextView moviePlot;
    TextView ratings;
    TextView releaseDate;
    RatingBar rateStar;

    private final String BASEURL = "http://image.tmdb.org/t/p/";
    StringBuilder imageUrl  = new StringBuilder(BASEURL);

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.detail_activity);
        populateUI();
        }
        public void  populateUI(){
            imageView = findViewById(R.id.imageView3);
            movieTitle = findViewById(R.id.textView2);
            moviePlot = findViewById(R.id.moviePlot2);
            ratings = findViewById(R.id.ratings);
            releaseDate = findViewById(R.id.releaseDate2);
            rateStar = findViewById(R.id.ratingBar);
            movie movieData =  getIntent().getParcelableExtra("MOVIE_DATA");
            setTitle(movieData.getMovieTitle());
            movieTitle.setText(movieData.getMovieTitle());
            moviePlot.setText(movieData.getMoviePlot());
            ratings.setText(movieData.getMovieRating());
            releaseDate.setText(movieData.getReleaseDate());
            rateStar.setRating(Float.parseFloat(movieData.getMovieRating()));
            if(movieData.getBackDrop().isEmpty() || movieData.getBackDrop().equals("null")){
                imageUrl.append("original/").append(movieData.getMovieImage());
                Picasso.with(getApplicationContext()).
                        load(imageUrl.toString())
                        .error(R.drawable.image1)
                        .placeholder(R.drawable.image1)
                        .into(imageView);
                return;
            }
            imageUrl.append("original/").append(movieData.getBackDrop());
            Picasso.with(getApplicationContext()).load(imageUrl.toString()).into(imageView);
        }
}
