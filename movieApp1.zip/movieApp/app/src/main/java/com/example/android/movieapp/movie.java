package com.example.android.movieapp;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;
import java.util.List;

public class movie implements Parcelable {

    private String movieTitle;
    private String moviePlot;
    private String releaseDate;
    private String  movieImage;
    private String movieRating;
    private String backDrop;


    public movie(){
    }
    public movie(String movieTitle, String moviePlot, String releaseDate, String movieImage,String movieRating, String backDrop ){
        this.movieTitle = movieTitle;
        this.moviePlot = moviePlot;
        this.releaseDate = releaseDate;
        this.movieImage = movieImage;
        this.movieRating = movieRating;
        this.backDrop = backDrop;

    }

    public String getBackDrop() {
        return backDrop;
    }

    public String getMovieTitle() {
        return movieTitle;
    }

    public String getMoviePlot() {
        return moviePlot;
    }

    public String getReleaseDate() {
        return releaseDate;
    }

    public String getMovieImage() {
        return movieImage;
    }

    public String getMovieRating() {
        return movieRating;
    }

    public void setMoviePlot(String moviePlot) {
        this.moviePlot = moviePlot;
    }

    public void setReleaseDate(String releaseDate) {
        this.releaseDate = releaseDate;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(this.movieTitle);
        parcel.writeString(this.movieImage);
        parcel.writeString(this.moviePlot);
        parcel.writeString(this.movieRating);
        parcel.writeString(this.releaseDate);
        parcel.writeString(this.backDrop);
    }

   private movie(Parcel in){
        this.movieTitle = in.readString();
        this.movieImage = in.readString();
        this.moviePlot = in.readString();
        this.movieRating = in.readString();
        this.releaseDate = in.readString();
        this.backDrop = in.readString();
   }

   public static final Parcelable.Creator<movie> CREATOR = new Parcelable.Creator<movie>(){

       @Override
       public movie createFromParcel(Parcel parcel) {
           return  new movie(parcel);
       }

       @Override
       public movie[] newArray(int i) {
           return new movie[i];
       }
   };

}
