package com.example.android.movieapp;

import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Adapter;
import android.widget.LinearLayout;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import static android.widget.LinearLayout.VERTICAL;

public class MainActivity extends AppCompatActivity {
    RecyclerView mRecyclerView;
    public static final String MOVIE_URL = "https://api.themoviedb.org/3/" +
            "discover/movie?api_key=af6a7bb450028de8aefd99dec516ebb4&language" +
            "=en-US&sort_by=popularity.desc&include_adult" +
            "=false&include_video=false&page=1";
    public static final String TOP_RATED_URL = "https://api.themoviedb.org/3/discover/movie?" +
            "api_key=af6a7bb450028de8aefd99dec516ebb4&language=en-US&sort_by" +
            "=vote_average.desc&include_adult=false&include_video=false&page=1";

    List<movie> result = new ArrayList<>();
    private MovieAdapter myAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mRecyclerView =  findViewById(R.id.movieRecycler);
        mRecyclerView.setHasFixedSize(true);
        GridLayoutManager movieGrid = new GridLayoutManager(this, getSpanCount());
        mRecyclerView.setLayoutManager(movieGrid);
        myAdapter = new MovieAdapter(this,result);
        mRecyclerView.setAdapter(myAdapter);
        //make the network call and update the UI
        new MovieAsynTask().execute(MOVIE_URL);
        //calculate the width of the device and divide by 250 to fill it up equally
        getSpanCount();
    }

    //menu items for the user to choose between top rated or popular movies
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.movie_query, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.popularMovies:
                new MovieAsynTask().execute(MOVIE_URL);
                return true;
            case R.id.topRated:
                new MovieAsynTask().execute(TOP_RATED_URL);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    //calculate with of divide by 250 to fill width equally
    public int getSpanCount(){
        DisplayMetrics metrics = new DisplayMetrics();
         getWindowManager().getDefaultDisplay().getMetrics(metrics);
         return metrics.widthPixels/250;
    }

    //movie AsyncTask to make the work call
    //retrieve data and update the UI
    private class MovieAsynTask extends AsyncTask<String, Void ,List<movie>>{
        OkHttpClient client = new OkHttpClient();
        String dataHandler;

        @Override
        protected List<movie> doInBackground(String... strings) {
            Request request = new Request.Builder().url(strings[0]).build();
            try {
                Response response = client.newCall(request).execute();
                dataHandler = response.body().string();
                result = MovieJsonUtil.parseMovieJson(dataHandler);
            } catch (IOException e) {
                e.printStackTrace();
            }
            return result;
        }
        protected  void onPostExecute(List<movie> moviePost){
            myAdapter.updateoMovieAdapter(moviePost);
        }
    }
}
