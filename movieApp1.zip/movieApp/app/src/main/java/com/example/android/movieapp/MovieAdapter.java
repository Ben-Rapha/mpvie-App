package com.example.android.movieapp;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import java.net.URL;

import android.os.Parcelable;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.List;


public class MovieAdapter extends RecyclerView.Adapter<MovieAdapter.ViewHolder>{
    private List<movie> movieContainer;
    private Context mcontext;
    private final String BASEURL = "http://image.tmdb.org/t/p/";
    private final String posterSize = "original";

    public MovieAdapter(Context context, List<movie> movieHolder){
        this.mcontext = context;
        movieContainer = movieHolder;
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        public ImageView imageView;
        public ViewHolder(View dataView){
            super(dataView);
            imageView = dataView.findViewById(R.id.movieImageView);
        }
    }
    @NonNull
    @Override
    public MovieAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType){
        View convertView = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_layout,parent,false);
        return new ViewHolder(convertView);
    }
    @Override
    public void onBindViewHolder(MovieAdapter.ViewHolder holder, final int position) {
        final movie movieApp = movieContainer.get(position);
        StringBuilder imageUrl  = new StringBuilder(BASEURL);
        imageUrl.append("original/").append(movieApp.getMovieImage());
        Picasso.with(mcontext).load(imageUrl.
                toString()).
                fit().error(R.drawable.image1).
                placeholder(R.drawable.image1).
                into(holder.imageView);
        holder.imageView.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(view.getContext(), DetailActivity.class);
                intent.putExtra("MOVIE_DATA", movieApp);
                view.getContext().startActivities(new Intent[]{intent});
            }
        });


    }
    @Override
    public int getItemCount() {
        return movieContainer.size();
    }

    public void updateoMovieAdapter(List<movie> update){
        this.movieContainer = update;
        notifyDataSetChanged();
    }





}